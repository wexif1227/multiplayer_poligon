# Poligon Unity — готовый каркас

## Старт за 1 минуту

1. Unity Hub → Open → папка `PoligonUnity`
2. Дождись импорта
3. В меню сверху: **Poligon → Setup Scene (one click)**
4. Нажми **Play**

Или вручную: Create Empty → Add Component `GameBootstrap` → Play.

## Управление

| Клавиша | Действие |
|---------|----------|
| WASD | Ходьба |
| Shift | Бег |
| Мышь | Обзор |
| ЛКМ | Стрельба |
| R | Перезарядка |
| 1–5 | Оружие (AK, M4, AWP, Glock, Knife) |
| Tab | Мультиплеер |
| Esc | Курсор |

## На экране

- Слева: HP, оружие, K/D
- Справа снизу: патроны
- Красные капсулы = боты (можно стрелять)

## Мультиплеер (Render / localhost)

```
cd Server
npm install
npm start
```

В игре Tab → Server `ws://localhost:3000` → Connect.

## Структура

```
Assets/Scripts/
  Core/        GameBootstrap, enums
  Player/      движение
  Weapons/     стрельба, оружие
  Network/     WebSocket, MP
  Combat/      боты
  UI/          HUD
  World/       арена
Server/        Node.js для Render
```
