#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using Poligon.Weapons;

namespace Poligon.Editor
{
    /// Меню: Poligon / Build Weapon & Skin Prefabs
    /// Берёт .glb из Assets/models (импортирует glTFast), сам поворачивает ствол вперёд (+Z),
    /// ставит "верх" вверх, масштабирует до реального размера и сохраняет префабы в Resources.
    public static class SkinImporter
    {
        const string ModelsDir = "Assets/models/";
        const string VmDir = "Assets/Resources/ViewModels";
        const string SkinDir = "Assets/Resources/Skins";
        const string WeaponDir = "Assets/Resources/Weapons";

        class WeaponEntry
        {
            public WeaponId id; public string name; public string file; public string texture; // texture: если у модели нет своей (FBX)
            public float length;      // длина оружия, метров
            public float zCenter;     // где центр модели относительно "Muzzle" вдоль взгляда
            public bool flip;         // true, если ствол смотрит не туда (авто-определение ошиблось)
            public int mag, reserve; public float interval; public bool auto; public int dmg; public bool melee;
        }

        static readonly WeaponEntry[] Weapons =
        {
            new WeaponEntry { id = WeaponId.ak47,  name = "AK-47",              file = "ak-47_prinstream__csgo_2.glb",           length = 0.85f, zCenter = 0.20f, mag = 30, reserve = 90, interval = 0.10f, auto = true,  dmg = 36 },
            new WeaponEntry { id = WeaponId.m4a1s, name = "M4A1-S | PRINTSTREAM", file = "M4A1SPRINTSTREAM.fbx", texture = "M4A1SPRINTSTREAM.jpeg", length = 0.80f, zCenter = 0.20f, mag = 25, reserve = 75, interval = 0.085f, auto = true, dmg = 33 },
            new WeaponEntry { id = WeaponId.awp,   name = "AWP | GZHEL",        file = "awp-csgo_gzhel.glb",                     length = 1.15f, zCenter = 0.25f, mag = 10, reserve = 30, interval = 1.2f,  auto = false, dmg = 115 },
            new WeaponEntry { id = WeaponId.glock, name = "Glock-18",           file = "glock_gun_3d_model_free_download.glb",   length = 0.22f, zCenter = 0.08f, mag = 20, reserve = 120, interval = 0.11f, auto = false, dmg = 28 },
            new WeaponEntry { id = WeaponId.usp,   name = "USP-S | 200 IQ",     file = "usp-s.obj", texture = "usp-s_200iq.png",  length = 0.32f, zCenter = 0.12f, mag = 12, reserve = 24, interval = 0.15f, auto = false, dmg = 35 },
            new WeaponEntry { id = WeaponId.knife, name = "НОЖ-БАБОЧКА",        file = "butterfly.glb",                          length = 0.50f, zCenter = 0.18f, mag = 1,  reserve = 0,  interval = 0.5f,  auto = false, dmg = 65, melee = true },
        };

        [MenuItem("Poligon/Build Weapon & Skin Prefabs")]
        public static void BuildAll()
        {
            Directory.CreateDirectory(VmDir);
            Directory.CreateDirectory(SkinDir);
            Directory.CreateDirectory(WeaponDir);
            AssetDatabase.Refresh();

            int built = 0;
            foreach (var e in Weapons)
            {
                var data = GetOrCreateData(e);
                if (!string.IsNullOrEmpty(e.file) && File.Exists(ModelsDir + e.file))
                {
                    var prefab = BuildGun(e);
                    if (prefab != null) { data.viewModelPrefab = prefab; built++; }
                }
                else if (!string.IsNullOrEmpty(e.file))
                    Debug.LogWarning("[Poligon] Нет файла " + ModelsDir + e.file + " — для " + e.id + " останется процедурная модель.");
                EditorUtility.SetDirty(data);
            }

            // Скин игрока (по сети видят другие)
            if (File.Exists(ModelsDir + "chicken_gun_real_rudy_model.glb"))
                if (BuildPlayerSkin("chicken_gun_real_rudy_model.glb", "Player_Chicken", 1.8f, 0f) != null) built++;

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("[Poligon] Готово. Префабов собрано: " + built);
        }

        // ---------- Оружие ----------
        static GameObject BuildGun(WeaponEntry e)
        {
            string src = ModelsDir + e.file;
            var model = LoadModel(src);
            if (model == null) return null;

            if (!string.IsNullOrEmpty(e.texture)) ApplyTexture(model, ModelsDir + e.texture, "VM_" + e.id);

            var root = new GameObject("VM_" + e.id);
            model.transform.SetParent(root.transform, false);

            // 1) Поворот вокруг Y: длинная ось (PCA по XZ) -> +Z, ствол вперёд.
            var verts = WorldVerts(model);
            if (verts.Count < 10) { Debug.LogError("[Poligon] Пустая модель: " + src); Object.DestroyImmediate(root); return null; }

            Vector2 mean = Vector2.zero;
            foreach (var v in verts) mean += new Vector2(v.x, v.z);
            mean /= verts.Count;
            double sxx = 0, szz = 0, sxz = 0;
            foreach (var v in verts)
            {
                double dx = v.x - mean.x, dz = v.z - mean.y;
                sxx += dx * dx; szz += dz * dz; sxz += dx * dz;
            }
            double ang = 0.5 * System.Math.Atan2(2 * sxz, sxx - szz);
            var a = new Vector2((float)System.Math.Cos(ang), (float)System.Math.Sin(ang));
            var perp = new Vector2(-a.y, a.x);

            float tMin = float.MaxValue, tMax = float.MinValue;
            var t = new float[verts.Count];
            for (int i = 0; i < verts.Count; i++)
            {
                var p = new Vector2(verts[i].x, verts[i].z) - mean;
                t[i] = Vector2.Dot(p, a);
                if (t[i] < tMin) tMin = t[i];
                if (t[i] > tMax) tMax = t[i];
            }
            float L = tMax - tMin;
            float areaA = EndArea(verts, t, perp, mean, tMin, tMin + 0.15f * L);
            float areaB = EndArea(verts, t, perp, mean, tMax - 0.15f * L, tMax);
            int muzzleSign = areaB < areaA ? 1 : -1;   // у ствола сечение меньше, чем у приклада/рукояти
            if (e.flip) muzzleSign = -muzzleSign;

            var dir3 = new Vector3(a.x, 0f, a.y) * muzzleSign;
            model.transform.rotation = Quaternion.FromToRotation(dir3, Vector3.forward);

            // 2) Масштаб по длине.
            var b = BoundsOf(model);
            float s = e.length / Mathf.Max(0.0001f, b.size.z);
            model.transform.localScale = Vector3.one * s;

            // 3) Позиция: центр модели в (0.02, 0, zCenter).
            b = BoundsOf(model);
            model.transform.position += new Vector3(0.02f, 0f, e.zCenter) - b.center;

            return SavePrefab(root, VmDir + "/VM_" + e.id + ".prefab");
        }

        // Материал с текстурой для моделей, у которых путь к текстуре «потерялся» (как у FBX с чужого диска).
        static void ApplyTexture(GameObject model, string texPath, string matName)
        {
            AssetDatabase.ImportAsset(texPath, ImportAssetOptions.ForceUpdate);
            var tex = AssetDatabase.LoadAssetAtPath<Texture2D>(texPath);
            if (tex == null) { Debug.LogWarning("[Poligon] Текстура не найдена: " + texPath); return; }

            var mat = new Material(Shader.Find("Standard"));
            mat.mainTexture = tex;
            mat.SetFloat("_Metallic", 0.6f);
            mat.SetFloat("_Glossiness", 0.65f);
            string mp = VmDir + "/" + matName + "_mat.mat";
            AssetDatabase.DeleteAsset(mp);
            AssetDatabase.CreateAsset(mat, mp);

            foreach (var r in model.GetComponentsInChildren<Renderer>(true))
            {
                var arr = new Material[Mathf.Max(1, r.sharedMaterials.Length)];
                for (int i = 0; i < arr.Length; i++) arr[i] = mat;
                r.sharedMaterials = arr;
            }
        }

        static float EndArea(List<Vector3> verts, float[] t, Vector2 perp, Vector2 mean, float lo, float hi)
        {
            float yMin = float.MaxValue, yMax = float.MinValue, wMin = float.MaxValue, wMax = float.MinValue;
            int n = 0;
            for (int i = 0; i < verts.Count; i++)
            {
                if (t[i] < lo || t[i] > hi) continue;
                n++;
                float w = Vector2.Dot(new Vector2(verts[i].x, verts[i].z) - mean, perp);
                yMin = Mathf.Min(yMin, verts[i].y); yMax = Mathf.Max(yMax, verts[i].y);
                wMin = Mathf.Min(wMin, w); wMax = Mathf.Max(wMax, w);
            }
            return n < 5 ? 0f : (yMax - yMin) * (wMax - wMin);
        }

        // ---------- Скин игрока ----------
        static GameObject BuildPlayerSkin(string file, string prefabName, float height, float yaw)
        {
            string src = ModelsDir + file;
            var model = LoadModel(src);
            if (model == null) return null;
            var root = new GameObject(prefabName);
            model.transform.SetParent(root.transform, false);
            model.transform.rotation = Quaternion.Euler(0f, yaw, 0f);   // если смотрит назад — поставь 180 тут

            var b = BoundsOf(model);
            model.transform.localScale = Vector3.one * (height / Mathf.Max(0.0001f, b.size.y));
            b = BoundsOf(model);
            // ноги на y = 0, центр по XZ
            model.transform.position += new Vector3(-b.center.x, -b.min.y, -b.center.z);
            return SavePrefab(root, SkinDir + "/" + prefabName + ".prefab");
        }

        // ---------- Общее ----------
        static GameObject LoadModel(string path)
        {
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            var src = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (src == null)
            {
                Debug.LogError("[Poligon] Не удалось загрузить " + path +
                    ". Установлен ли пакет glTFast (com.unity.cloud.gltfast)? Если да — удали файл " + path + ".meta и дай Unity переимпортировать.");
                return null;
            }
            var go = Object.Instantiate(src);
            go.name = "Model";
            go.transform.position = Vector3.zero;
            go.transform.rotation = Quaternion.identity;
            go.transform.localScale = Vector3.one;
            foreach (var c in go.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
            foreach (var r in go.GetComponentsInChildren<Renderer>(true)) { r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off; }
            return go;
        }

        static List<Vector3> WorldVerts(GameObject go)
        {
            var list = new List<Vector3>();
            foreach (var mf in go.GetComponentsInChildren<MeshFilter>())
            {
                if (mf.sharedMesh == null) continue;
                var m = mf.transform.localToWorldMatrix;
                foreach (var v in mf.sharedMesh.vertices) list.Add(m.MultiplyPoint3x4(v));
            }
            foreach (var sk in go.GetComponentsInChildren<SkinnedMeshRenderer>())
            {
                if (sk.sharedMesh == null) continue;
                var m = sk.transform.localToWorldMatrix;
                foreach (var v in sk.sharedMesh.vertices) list.Add(m.MultiplyPoint3x4(v));
            }
            return list;
        }

        static Bounds BoundsOf(GameObject go)
        {
            var v = WorldVerts(go);
            var b = new Bounds(v[0], Vector3.zero);
            foreach (var p in v) b.Encapsulate(p);
            return b;
        }

        static GameObject SavePrefab(GameObject root, string path)
        {
            var prefab = PrefabUtility.SaveAsPrefabAsset(root, path);
            Object.DestroyImmediate(root);
            Debug.Log("[Poligon] Сохранён " + path);
            return prefab;
        }

        static WeaponData GetOrCreateData(WeaponEntry e)
        {
            foreach (var guid in AssetDatabase.FindAssets("t:WeaponData"))
            {
                var existing = AssetDatabase.LoadAssetAtPath<WeaponData>(AssetDatabase.GUIDToAssetPath(guid));
                if (existing != null && existing.id == e.id) return existing;
            }
            var w = ScriptableObject.CreateInstance<WeaponData>();
            w.id = e.id; w.displayName = e.name; w.magSize = e.mag; w.reserveMax = e.reserve;
            w.fireInterval = e.interval; w.automatic = e.auto; w.melee = e.melee;
            w.reloadTime = e.melee ? 0.1f : 2.15f;
            w.damageHead = 100; w.damageBody = e.dmg; w.damageLeg = e.dmg / 2;
            w.baseSpread = e.melee ? 0f : 0.035f; w.maxSpread = 2.6f; w.spreadPerShot = 0.15f;
            w.moveSpreadMult = 4.2f; w.range = e.melee ? 2.6f : 150f;
            AssetDatabase.CreateAsset(w, WeaponDir + "/" + e.id + ".asset");
            return w;
        }
    }
}
#endif
