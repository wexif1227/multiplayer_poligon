using UnityEngine;

namespace Poligon.Network
{
    public class RemotePlayer : MonoBehaviour
    {
        public TextMesh nameLabel;
        public string NetId { get; private set; }
        public string DisplayName { get; private set; } = "Player";
        public int Hp { get; private set; } = 100;
        public string Weapon { get; private set; } = "ak47";

        Vector3 _targetPos;
        float _targetYaw;
        bool _hasState;

        public Vector3 AimPoint => transform.position + Vector3.up * 1.05f;

        /// Тело по умолчанию: скин Resources/Skins/Player_Chicken (его собирает Poligon/Build Weapon & Skin Prefabs),
        /// а если его нет — красная капсула. Имя над головой.
        public static RemotePlayer CreateDefault()
        {
            var root = new GameObject("RemotePlayer");
            var rp = root.AddComponent<RemotePlayer>();

            var skin = Resources.Load<GameObject>("Skins/Player_Chicken");
            if (skin != null)
            {
                var s = Instantiate(skin, root.transform);
                s.transform.localPosition = Vector3.zero;
                s.transform.localRotation = Quaternion.identity;
            }
            else
            {
                var body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                body.transform.SetParent(root.transform, false);
                body.transform.localPosition = Vector3.up * 0.9f;
                body.transform.localScale = new Vector3(0.7f, 0.9f, 0.7f);
                var sh = Shader.Find("Standard");
                if (sh != null)
                {
                    var mat = new Material(sh) { color = new Color(0.2f, 0.45f, 0.95f) };
                    body.GetComponent<Renderer>().sharedMaterial = mat;
                }
            }
            foreach (var c in root.GetComponentsInChildren<Collider>()) Destroy(c);

            var labelGo = new GameObject("NameLabel");
            labelGo.transform.SetParent(root.transform, false);
            labelGo.transform.localPosition = Vector3.up * 2.1f;
            var tm = labelGo.AddComponent<TextMesh>();
            var font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            tm.font = font;
            labelGo.GetComponent<MeshRenderer>().sharedMaterial = font.material;
            tm.text = "Player";
            tm.characterSize = 0.1f;
            tm.fontSize = 64;
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            tm.color = Color.white;
            rp.nameLabel = tm;
            return rp;
        }

        public void ApplyState(MpPlayer p)
        {
            NetId = p.id;
            if (!string.IsNullOrEmpty(p.name))
            {
                DisplayName = p.name;
                if (nameLabel) nameLabel.text = p.name;
            }
            _targetPos = new Vector3(p.x, p.y, p.z);
            _targetYaw = p.yaw * Mathf.Rad2Deg;
            if (!_hasState) { transform.position = _targetPos; _hasState = true; } // без «пролёта» из (0,0,0)
            if (p.hp > 0) Hp = p.hp;
            if (!string.IsNullOrEmpty(p.weapon)) Weapon = p.weapon;
        }

        public void SetHp(int hp) => Hp = hp;
        public void PlayShot(string weapon) { Weapon = weapon ?? Weapon; }

        public void Tick(float dt)
        {
            transform.position = Vector3.Lerp(transform.position, _targetPos, 1f - Mathf.Exp(-14f * dt));
            var e = transform.eulerAngles;
            e.y = Mathf.LerpAngle(e.y, _targetYaw, 1f - Mathf.Exp(-14f * dt));
            transform.eulerAngles = e;

            // имя всегда лицом к камере
            var cam = Camera.main;
            if (nameLabel && cam) nameLabel.transform.rotation = cam.transform.rotation;
        }
    }
}
